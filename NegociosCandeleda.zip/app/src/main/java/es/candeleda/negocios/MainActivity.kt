package es.candeleda.negocios

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val Oro = Color(0xFFF0C45C)
private val Bosque = Color(0xFF12231B)
private val Cristal = Color(0xB3102019)
private val Verde = Color(0xFF7BD389)
private val Rojo = Color(0xFFFF8A80)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val negocios = cargarNegocios(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Oro, background = Bosque, surface = Bosque)) {
                Surface(color = Color.Transparent, contentColor = Color.White) {
                    Pantalla(negocios)
                }
            }
        }
    }
}

private fun abrir(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "No se ha podido abrir", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun Pantalla(negocios: List<Negocio>) {
    var seleccionado by remember { mutableStateOf<Negocio?>(null) }
    val actual = seleccionado

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(
            painter = painterResource(R.drawable.fondo),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0x99000000), Color(0x8012231B), Color(0xE612231B)),
                ),
            ),
        )
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            if (actual == null) {
                Inicio(negocios) { seleccionado = it }
            } else {
                BackHandler { seleccionado = null }
                Ficha(actual) { seleccionado = null }
            }
        }
    }
}

@Composable
fun Inicio(negocios: List<Negocio>, onClick: (Negocio) -> Unit) {
    var busqueda by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("Todos") }
    val categorias = remember(negocios) { listOf("Todos") + negocios.map { it.categoria }.distinct() }
    val filtrados = negocios.filter {
        (categoria == "Todos" || it.categoria == categoria) &&
            it.nombre.contains(busqueda.trim(), ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Image(
                painter = painterResource(R.drawable.logo_banner),
                contentDescription = "Negocios Candeleda",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color(0x55F0C45C), RoundedCornerShape(24.dp)),
                contentScale = ContentScale.FillWidth,
            )
        }
        item {
            OutlinedTextField(
                value = busqueda,
                onValueChange = { busqueda = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar un negocio", color = Color(0xB3FFFFFF)) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Oro,
                    unfocusedBorderColor = Color(0x66FFFFFF),
                    focusedContainerColor = Cristal,
                    unfocusedContainerColor = Cristal,
                    cursorColor = Oro,
                ),
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categorias) { c ->
                    val activa = c == categoria
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (activa) Oro else Cristal)
                            .border(1.dp, if (activa) Oro else Color(0x55FFFFFF), RoundedCornerShape(50))
                            .clickable { categoria = c }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    ) {
                        Text(
                            c,
                            color = if (activa) Bosque else Color.White,
                            fontWeight = if (activa) FontWeight.Bold else FontWeight.Normal,
                        )
                    }
                }
            }
        }
        items(filtrados) { n -> TarjetaNegocio(n) { onClick(n) } }
        if (filtrados.isEmpty()) {
            item {
                Text(
                    "No hay negocios con ese nombre en esta categoría.",
                    modifier = Modifier.padding(8.dp),
                    color = Color(0xCCFFFFFF),
                )
            }
        }
    }
}

@Composable
fun EstadoAbierto(n: Negocio) {
    when (estaAbierto(n)) {
        true -> Text("● Abierto ahora", color = Verde, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        false -> Text("● Cerrado ahora", color = Rojo, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        null -> Text("Horario no disponible", color = Color(0xB3FFFFFF), fontSize = 14.sp)
    }
}

@Composable
fun TarjetaNegocio(n: Negocio, onClick: () -> Unit) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(forma)
            .background(Cristal)
            .border(1.dp, Color(0x33FFFFFF), forma)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(n.nombre, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(n.categoria, color = Oro, fontSize = 14.sp)
        EstadoAbierto(n)
    }
}

@Composable
fun Ficha(n: Negocio, volver: () -> Unit) {
    val context = LocalContext.current
    val hoy = LocalDate.now().dayOfWeek.value

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TextButton(onClick = volver) { Text("Volver", color = Oro, fontSize = 16.sp) }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(n.nombre, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 36.sp)
            Text(n.categoria, color = Oro, fontSize = 16.sp)
            EstadoAbierto(n)
        }

        if (n.descripcion.isNotBlank()) {
            Text(n.descripcion, fontSize = 16.sp, lineHeight = 22.sp, color = Color(0xE6FFFFFF))
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (n.telefono.isNotBlank()) {
                BotonAccion("Llamar al ${n.telefono}") {
                    abrir(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:${n.telefono}")))
                }
            }
            if (n.web.isNotBlank()) {
                val url = if (n.web.startsWith("http")) n.web else "https://${n.web}"
                BotonAccion("Abrir su web") { abrir(context, Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            } else {
                Text("Este negocio aún no tiene web.", color = Color(0xB3FFFFFF), fontSize = 14.sp)
            }
            if (n.direccion.isNotBlank()) {
                BotonAccion("Cómo llegar") {
                    val q = Uri.encode("${n.direccion}, Candeleda")
                    abrir(context, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
                }
            }
        }

        Bloque("Horario") {
            if (n.horario.isEmpty()) {
                Text("Horario no disponible", color = Color(0xB3FFFFFF))
            } else {
                NOMBRES_DIAS.forEachIndexed { i, dia ->
                    val tramos = n.horario[i + 1].orEmpty()
                    val esHoy = i + 1 == hoy
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(dia, fontWeight = if (esHoy) FontWeight.Bold else FontWeight.Normal, color = if (esHoy) Oro else Color.White)
                        Text(
                            if (tramos.isEmpty()) "Cerrado" else tramos.joinToString("  y  "),
                            fontWeight = if (esHoy) FontWeight.Bold else FontWeight.Normal,
                            color = if (esHoy) Oro else Color.White,
                        )
                    }
                }
            }
        }

        if (n.carta.isNotEmpty()) {
            Bloque("Carta y productos") {
                n.carta.forEach { p ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.nombre, modifier = Modifier.weight(1f))
                        if (p.precio.isNotBlank()) Text(p.precio, color = Oro, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun BotonAccion(texto: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Oro, contentColor = Bosque),
    ) {
        Text(texto, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun Bloque(titulo: String, contenido: @Composable () -> Unit) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(forma)
            .background(Cristal)
            .border(1.dp, Color(0x33FFFFFF), forma)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(titulo, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        contenido()
    }
}
