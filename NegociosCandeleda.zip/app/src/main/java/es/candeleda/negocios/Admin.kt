package es.candeleda.negocios

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private fun aviso(context: Context, texto: String) {
    Toast.makeText(context, texto, Toast.LENGTH_LONG).show()
}

@Composable
private fun coloresCampo() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Oro,
    unfocusedBorderColor = Color(0x66FFFFFF),
    focusedContainerColor = Cristal,
    unfocusedContainerColor = Cristal,
    cursorColor = Oro,
    focusedLabelColor = Oro,
    unfocusedLabelColor = Color(0xB3FFFFFF),
)

@Composable
private fun Campo(
    valor: String,
    cambia: (String) -> Unit,
    etiqueta: String,
    lineas: Int = 1,
    teclado: KeyboardType = KeyboardType.Text,
) {
    OutlinedTextField(
        value = valor,
        onValueChange = cambia,
        label = { Text(etiqueta) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = lineas == 1,
        minLines = lineas,
        shape = RoundedCornerShape(14.dp),
        colors = coloresCampo(),
        keyboardOptions = KeyboardOptions(keyboardType = teclado),
    )
}

@Composable
private fun Chip(texto: String, activa: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(forma)
            .background(if (activa) Oro else Cristal)
            .border(1.dp, if (activa) Oro else Color(0x55FFFFFF), forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(
            texto,
            color = if (activa) Bosque else Color.White,
            fontWeight = if (activa) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun Titulo(texto: String) {
    Text(texto, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 28.sp)
}

// ------------------------------------------------------------------ acceso

@Composable
fun PantallaLogin(onOk: () -> Unit, volver: () -> Unit) {
    val context = LocalContext.current
    BackHandler { volver() }
    var correo by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var entrando by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TextButton(onClick = volver) { Text("Volver", color = Oro, fontSize = 16.sp) }
        Titulo("Acceso del creador")
        Campo(correo, { correo = it }, "Correo", teclado = KeyboardType.Email)
        OutlinedTextField(
            value = clave,
            onValueChange = { clave = it },
            label = { Text("Contraseña") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            shape = RoundedCornerShape(14.dp),
            colors = coloresCampo(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        BotonAccion(if (entrando) "Entrando…" else "Entrar") {
            if (entrando) return@BotonAccion
            if (correo.isBlank() || clave.isEmpty()) {
                aviso(context, "Escribe el correo y la contraseña")
                return@BotonAccion
            }
            entrando = true
            Nube.entrar(
                correo,
                clave,
                ok = {
                    entrando = false
                    onOk()
                },
                error = {
                    entrando = false
                    aviso(context, it)
                },
            )
        }
    }
}

// ------------------------------------------------------------------ panel

@Composable
fun PanelAdmin(
    negocios: List<Negocio>,
    anuncios: List<Anuncio>,
    localesN: List<Negocio>,
    localesE: OfertasEmpleo,
    volver: () -> Unit,
) {
    val context = LocalContext.current
    var editN by remember { mutableStateOf<Negocio?>(null) }
    var editA by remember { mutableStateOf<Anuncio?>(null) }
    var pestana by remember { mutableStateOf(0) }
    var borrarN by remember { mutableStateOf<Negocio?>(null) }
    var borrarA by remember { mutableStateOf<Anuncio?>(null) }

    val en = editN
    val ea = editA

    if (en != null) {
        BackHandler { editN = null }
        EditorNegocio(en, negocios.map { it.categoria }.filter { it.isNotBlank() }.distinct()) { editN = null }
        return
    }
    if (ea != null) {
        BackHandler { editA = null }
        EditorAnuncio(ea) { editA = null }
        return
    }

    BackHandler { volver() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = volver) { Text("Volver", color = Oro, fontSize = 16.sp) }
                TextButton(onClick = {
                    Nube.salir()
                    volver()
                }) { Text("Cerrar sesión", color = Color(0xCCFFFFFF)) }
            }
        }
        item { Titulo("Panel de creador") }
        item {
            Text(
                "Lo que cambies aquí lo ve todo el mundo al momento, sin actualizar la app.",
                color = Color(0xCCFFFFFF),
                fontSize = 14.sp,
            )
        }
        if (negocios.isEmpty() && anuncios.isEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Todavía no hay nada en la nube. Puedes subir de una vez los negocios que lleva la app.",
                        fontSize = 15.sp,
                    )
                    BotonAccion("Importar datos iniciales") {
                        Nube.importar(
                            localesN,
                            localesE,
                            ok = { aviso(context, "Importado") },
                            error = { aviso(context, "No se ha podido importar: $it") },
                        )
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Negocios (${negocios.size})", pestana == 0) { pestana = 0 }
                Chip("Anuncios (${anuncios.size})", pestana == 1) { pestana = 1 }
            }
        }
        item {
            if (pestana == 0) {
                BotonAccion("Añadir negocio") {
                    editN = Negocio("", "", "", "", "", "", emptyMap(), emptyList())
                }
            } else {
                BotonAccion("Añadir anuncio") {
                    val hoy = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                    editA = Anuncio("", "", "", "", hoy, tipo = "trabajo")
                }
            }
        }
        if (pestana == 0) {
            items(negocios) { n ->
                FilaAdmin(n.nombre, n.categoria, onEditar = { editN = n }, onBorrar = { borrarN = n })
            }
        } else {
            items(anuncios) { a ->
                FilaAdmin(
                    a.titulo,
                    if (a.tipo == "trabajo") "Busco trabajo" else "Busco empleados",
                    onEditar = { editA = a },
                    onBorrar = { borrarA = a },
                )
            }
        }
    }

    val bn = borrarN
    if (bn != null) {
        AlertDialog(
            onDismissRequest = { borrarN = null },
            title = { Text("¿Borrar ${bn.nombre}?") },
            text = { Text("Dejará de verse en la app para todo el mundo.") },
            confirmButton = {
                TextButton(onClick = {
                    Nube.borrar("negocios", bn.id) { aviso(context, "No se ha podido borrar: $it") }
                    borrarN = null
                }) { Text("Borrar", color = Rojo) }
            },
            dismissButton = { TextButton(onClick = { borrarN = null }) { Text("Cancelar") } },
        )
    }
    val ba = borrarA
    if (ba != null) {
        AlertDialog(
            onDismissRequest = { borrarA = null },
            title = { Text("¿Borrar este anuncio?") },
            text = { Text(ba.titulo) },
            confirmButton = {
                TextButton(onClick = {
                    Nube.borrar("anuncios", ba.id) { aviso(context, "No se ha podido borrar: $it") }
                    borrarA = null
                }) { Text("Borrar", color = Rojo) }
            },
            dismissButton = { TextButton(onClick = { borrarA = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun FilaAdmin(titulo: String, subtitulo: String, onEditar: () -> Unit, onBorrar: () -> Unit) {
    val forma = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(forma)
            .background(Cristal)
            .border(1.dp, Color(0x33FFFFFF), forma)
            .padding(start = 16.dp, top = 8.dp, end = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(titulo, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitulo, color = Oro, fontSize = 13.sp)
        }
        TextButton(onClick = onEditar) { Text("Editar", color = Oro) }
        TextButton(onClick = onBorrar) { Text("Borrar", color = Rojo) }
    }
}

// ------------------------------------------------------------------ editores

private fun parsearTramos(texto: String): List<String>? {
    val partes = texto.split(",").map { it.trim().replace(" ", "") }.filter { it.isNotEmpty() }
    val formato = Regex("\\d{1,2}:\\d{2}-\\d{1,2}:\\d{2}")
    return if (partes.all { formato.matches(it) }) partes else null
}

@Composable
fun EditorNegocio(inicial: Negocio, categorias: List<String>, cerrar: () -> Unit) {
    val context = LocalContext.current
    var nombre by remember { mutableStateOf(inicial.nombre) }
    var categoria by remember { mutableStateOf(inicial.categoria) }
    var descripcion by remember { mutableStateOf(inicial.descripcion) }
    var telefono by remember { mutableStateOf(inicial.telefono) }
    var web by remember { mutableStateOf(inicial.web) }
    var direccion by remember { mutableStateOf(inicial.direccion) }
    val horarioTxt = remember {
        mutableStateListOf<String>().apply {
            for (i in 1..7) add(inicial.horario[i]?.joinToString(", ") ?: "")
        }
    }
    var carta by remember {
        mutableStateOf(
            inicial.carta.joinToString("\n") { if (it.precio.isBlank()) it.nombre else "${it.nombre} - ${it.precio}" },
        )
    }
    var guardando by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TextButton(onClick = cerrar) { Text("Cancelar", color = Oro, fontSize = 16.sp) }
        Titulo(if (inicial.id.isBlank()) "Nuevo negocio" else "Editar negocio")
        Campo(nombre, { nombre = it }, "Nombre")
        Campo(categoria, { categoria = it }, "Categoría (Bares, Panaderías…)")
        if (categorias.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categorias) { c -> Chip(c, c == categoria) { categoria = c } }
            }
        }
        Campo(descripcion, { descripcion = it }, "Descripción", lineas = 3)
        Campo(telefono, { telefono = it }, "Teléfono", teclado = KeyboardType.Phone)
        Campo(web, { web = it }, "Web (opcional)", teclado = KeyboardType.Uri)
        Campo(direccion, { direccion = it }, "Dirección (para «Cómo llegar»)")

        Text("Horario", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(
            "Tramos separados por coma, por ejemplo 09:00-14:00, 17:00-20:30. " +
                "Vacío = cerrado ese día. Si dejas todos los días vacíos, saldrá «Horario no disponible».",
            fontSize = 13.sp,
            color = Color(0xB3FFFFFF),
        )
        NOMBRES_DIAS.forEachIndexed { i, dia ->
            Campo(horarioTxt[i], { horarioTxt[i] = it }, dia)
        }

        Text("Carta y productos", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(
            "Uno por línea. Con precio así: Churros - 3,50 €",
            fontSize = 13.sp,
            color = Color(0xB3FFFFFF),
        )
        Campo(carta, { carta = it }, "Productos", lineas = 6)

        BotonAccion(if (guardando) "Guardando…" else "Guardar") {
            if (guardando) return@BotonAccion
            if (nombre.isBlank() || categoria.isBlank()) {
                aviso(context, "Pon al menos el nombre y la categoría")
                return@BotonAccion
            }
            val tramos = horarioTxt.map { parsearTramos(it) }
            if (tramos.any { it == null }) {
                aviso(context, "Revisa el horario: usa el formato 09:00-14:00")
                return@BotonAccion
            }
            val horario: Map<Int, List<String>> =
                if (horarioTxt.all { it.isBlank() }) {
                    emptyMap()
                } else {
                    tramos.mapIndexed { i, t -> (i + 1) to (t ?: emptyList()) }.toMap()
                }
            val platos = carta.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { linea ->
                val p = linea.split(" - ", limit = 2)
                Plato(p[0].trim(), p.getOrElse(1) { "" }.trim())
            }
            val negocio = Negocio(
                nombre = nombre.trim(),
                categoria = categoria.trim(),
                descripcion = descripcion.trim(),
                telefono = telefono.replace(" ", ""),
                web = web.trim(),
                direccion = direccion.trim(),
                horario = horario,
                carta = platos,
                id = inicial.id,
            )
            guardando = true
            Nube.guardarNegocio(
                negocio,
                ok = {
                    guardando = false
                    aviso(context, "Guardado")
                    cerrar()
                },
                error = {
                    guardando = false
                    aviso(context, "No se ha podido guardar: $it")
                },
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun EditorAnuncio(inicial: Anuncio, cerrar: () -> Unit) {
    val context = LocalContext.current
    var tipo by remember { mutableStateOf(inicial.tipo.ifBlank { "trabajo" }) }
    var titulo by remember { mutableStateOf(inicial.titulo) }
    var nombre by remember { mutableStateOf(inicial.nombre) }
    var descripcion by remember { mutableStateOf(inicial.descripcion) }
    var telefono by remember { mutableStateOf(inicial.telefono) }
    var fecha by remember { mutableStateOf(inicial.fecha) }
    var guardando by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TextButton(onClick = cerrar) { Text("Cancelar", color = Oro, fontSize = 16.sp) }
        Titulo(if (inicial.id.isBlank()) "Nuevo anuncio" else "Editar anuncio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Busco trabajo", tipo == "trabajo") { tipo = "trabajo" }
            Chip("Busco empleados", tipo == "empleados") { tipo = "empleados" }
        }
        Campo(titulo, { titulo = it }, "Título (Busco trabajo de camarero)")
        Campo(nombre, { nombre = it }, "Nombre de la persona o del negocio")
        Campo(descripcion, { descripcion = it }, "Descripción", lineas = 4)
        Campo(telefono, { telefono = it }, "Teléfono", teclado = KeyboardType.Phone)
        Campo(fecha, { fecha = it }, "Fecha de publicación")

        BotonAccion(if (guardando) "Guardando…" else "Guardar") {
            if (guardando) return@BotonAccion
            if (titulo.isBlank()) {
                aviso(context, "Pon un título al anuncio")
                return@BotonAccion
            }
            val anuncio = Anuncio(
                titulo = titulo.trim(),
                nombre = nombre.trim(),
                descripcion = descripcion.trim(),
                telefono = telefono.replace(" ", ""),
                fecha = fecha.trim(),
                id = inicial.id,
                tipo = tipo,
                creado = inicial.creado,
            )
            guardando = true
            Nube.guardarAnuncio(
                anuncio,
                ok = {
                    guardando = false
                    aviso(context, "Guardado")
                    cerrar()
                },
                error = {
                    guardando = false
                    aviso(context, "No se ha podido guardar: $it")
                },
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
