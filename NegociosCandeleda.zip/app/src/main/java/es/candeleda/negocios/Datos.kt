package es.candeleda.negocios

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime

data class Plato(val nombre: String, val precio: String)

data class Negocio(
    val nombre: String,
    val categoria: String,
    val descripcion: String,
    val telefono: String,
    val web: String,
    val direccion: String,
    /** Clave: día de la semana (1 = lunes ... 7 = domingo). Valor: tramos "HH:MM-HH:MM". */
    val horario: Map<Int, List<String>>,
    val carta: List<Plato>,
)

private val DIAS = listOf("lun", "mar", "mie", "jue", "vie", "sab", "dom")
val NOMBRES_DIAS = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")

fun cargarNegocios(context: Context): List<Negocio> = try {
    leerNegocios(context)
} catch (e: Exception) {
    emptyList()
}

private fun leerNegocios(context: Context): List<Negocio> {
    val texto = context.assets.open("negocios.json").bufferedReader().use { it.readText() }
    val arr = JSONArray(texto)
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val horario = mutableMapOf<Int, List<String>>()
        o.optJSONObject("horario")?.let { h ->
            DIAS.forEachIndexed { idx, clave ->
                val tramos = h.optJSONArray(clave)
                if (tramos != null) {
                    horario[idx + 1] = (0 until tramos.length()).map { tramos.getString(it) }
                }
            }
        }
        val carta = o.optJSONArray("carta")?.let { c ->
            (0 until c.length()).map {
                val p = c.getJSONObject(it)
                Plato(p.optString("nombre"), p.optString("precio"))
            }
        } ?: emptyList()
        Negocio(
            nombre = o.optString("nombre"),
            categoria = o.optString("categoria"),
            descripcion = o.optString("descripcion"),
            telefono = o.optString("telefono"),
            web = o.optString("web"),
            direccion = o.optString("direccion"),
            horario = horario,
            carta = carta,
        )
    }
}

private fun aMinutos(hhmm: String): Int {
    val p = hhmm.trim().split(":")
    return p[0].toInt() * 60 + p[1].toInt()
}

/** true = abierto, false = cerrado, null = no hay horario cargado. */
fun estaAbierto(n: Negocio, ahora: LocalDateTime = LocalDateTime.now()): Boolean? {
    if (n.horario.isEmpty()) return null
    val tramos = n.horario[ahora.dayOfWeek.value] ?: return false
    val minutos = ahora.hour * 60 + ahora.minute
    return tramos.any { t ->
        val partes = t.split("-")
        aMinutos(partes[0]) <= minutos && minutos < aMinutos(partes[1])
    }
}

data class Anuncio(
    val titulo: String,
    val nombre: String,
    val descripcion: String,
    val telefono: String,
    val fecha: String,
)

data class OfertasEmpleo(
    val buscanTrabajo: List<Anuncio>,
    val buscanEmpleados: List<Anuncio>,
)

private fun leerAnuncios(arr: JSONArray?): List<Anuncio> {
    if (arr == null) return emptyList()
    return (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        Anuncio(
            titulo = o.optString("titulo"),
            nombre = o.optString("nombre"),
            descripcion = o.optString("descripcion"),
            telefono = o.optString("telefono"),
            fecha = o.optString("fecha"),
        )
    }
}

fun cargarEmpleo(context: Context): OfertasEmpleo = try {
    val texto = context.assets.open("empleo.json").bufferedReader().use { it.readText() }
    val o = JSONObject(texto)
    OfertasEmpleo(
        leerAnuncios(o.optJSONArray("busco_trabajo")),
        leerAnuncios(o.optJSONArray("busco_empleados")),
    )
} catch (e: Exception) {
    OfertasEmpleo(emptyList(), emptyList())
}
