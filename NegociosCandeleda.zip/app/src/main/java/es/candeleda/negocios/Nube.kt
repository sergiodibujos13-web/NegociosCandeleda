package es.candeleda.negocios

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/** Todo lo que habla con Firebase: leer en vivo, guardar, borrar y el acceso del creador. */
object Nube {
    private fun db() = FirebaseFirestore.getInstance()
    private fun auth() = FirebaseAuth.getInstance()

    // ---------- lectura en vivo ----------

    fun escucharNegocios(alCambiar: (List<Negocio>) -> Unit): ListenerRegistration =
        db().collection("negocios").addSnapshotListener { snap, error ->
            if (error != null || snap == null) return@addSnapshotListener
            // Sin conexión y sin copia guardada: se queda con los datos que lleva la app.
            if (snap.isEmpty && snap.metadata.isFromCache) return@addSnapshotListener
            alCambiar(snap.documents.mapNotNull { negocioDe(it) }.sortedBy { it.nombre.lowercase() })
        }

    fun escucharAnuncios(alCambiar: (List<Anuncio>) -> Unit): ListenerRegistration =
        db().collection("anuncios").addSnapshotListener { snap, error ->
            if (error != null || snap == null) return@addSnapshotListener
            if (snap.isEmpty && snap.metadata.isFromCache) return@addSnapshotListener
            alCambiar(snap.documents.mapNotNull { anuncioDe(it) }.sortedByDescending { it.creado })
        }

    private fun negocioDe(d: DocumentSnapshot): Negocio? {
        val nombre = d.getString("nombre") ?: return null
        val horario = mutableMapOf<Int, List<String>>()
        val h = d.get("horario") as? Map<*, *>
        if (h != null) {
            DIAS.forEachIndexed { i, clave ->
                val tramos = h[clave] as? List<*>
                if (tramos != null) horario[i + 1] = tramos.mapNotNull { it as? String }
            }
        }
        val carta = (d.get("carta") as? List<*>)?.mapNotNull { e ->
            val m = e as? Map<*, *> ?: return@mapNotNull null
            Plato(m["nombre"] as? String ?: "", m["precio"] as? String ?: "")
        } ?: emptyList()
        return Negocio(
            nombre = nombre,
            categoria = d.getString("categoria") ?: "",
            descripcion = d.getString("descripcion") ?: "",
            telefono = d.getString("telefono") ?: "",
            web = d.getString("web") ?: "",
            direccion = d.getString("direccion") ?: "",
            horario = horario,
            carta = carta,
            id = d.id,
        )
    }

    private fun anuncioDe(d: DocumentSnapshot): Anuncio? {
        val titulo = d.getString("titulo") ?: return null
        return Anuncio(
            titulo = titulo,
            nombre = d.getString("nombre") ?: "",
            descripcion = d.getString("descripcion") ?: "",
            telefono = d.getString("telefono") ?: "",
            fecha = d.getString("fecha") ?: "",
            id = d.id,
            tipo = d.getString("tipo") ?: "trabajo",
            creado = d.getLong("creado") ?: 0L,
        )
    }

    // ---------- escritura (solo funciona con la cuenta del creador) ----------

    private fun datosNegocio(n: Negocio): Map<String, Any> = mapOf(
        "nombre" to n.nombre,
        "categoria" to n.categoria,
        "descripcion" to n.descripcion,
        "telefono" to n.telefono,
        "web" to n.web,
        "direccion" to n.direccion,
        "horario" to n.horario.entries.associate { DIAS[it.key - 1] to it.value },
        "carta" to n.carta.map { mapOf("nombre" to it.nombre, "precio" to it.precio) },
    )

    private fun datosAnuncio(a: Anuncio, tipo: String = a.tipo): Map<String, Any> = mapOf(
        "tipo" to tipo,
        "titulo" to a.titulo,
        "nombre" to a.nombre,
        "descripcion" to a.descripcion,
        "telefono" to a.telefono,
        "fecha" to a.fecha,
        "creado" to (if (a.creado == 0L) System.currentTimeMillis() else a.creado),
    )

    private fun guardar(
        coleccion: String,
        id: String,
        datos: Map<String, Any>,
        ok: () -> Unit,
        error: (String) -> Unit,
    ) {
        val col = db().collection(coleccion)
        if (id.isBlank()) {
            col.add(datos)
                .addOnSuccessListener { ok() }
                .addOnFailureListener { error(it.message ?: "Error desconocido") }
        } else {
            col.document(id).set(datos)
                .addOnSuccessListener { ok() }
                .addOnFailureListener { error(it.message ?: "Error desconocido") }
        }
    }

    fun guardarNegocio(n: Negocio, ok: () -> Unit, error: (String) -> Unit) =
        guardar("negocios", n.id, datosNegocio(n), ok, error)

    fun guardarAnuncio(a: Anuncio, ok: () -> Unit, error: (String) -> Unit) =
        guardar("anuncios", a.id, datosAnuncio(a), ok, error)

    fun borrar(coleccion: String, id: String, error: (String) -> Unit) {
        db().collection(coleccion).document(id).delete()
            .addOnFailureListener { error(it.message ?: "Error desconocido") }
    }

    /** Sube de una vez los negocios y anuncios que lleva la app, para no escribirlos otra vez. */
    fun importar(negocios: List<Negocio>, empleo: OfertasEmpleo, ok: () -> Unit, error: (String) -> Unit) {
        val batch = db().batch()
        negocios.forEach { batch.set(db().collection("negocios").document(), datosNegocio(it)) }
        var t = System.currentTimeMillis()
        empleo.buscanTrabajo.forEach {
            batch.set(db().collection("anuncios").document(), datosAnuncio(it.copy(creado = t++), "trabajo"))
        }
        empleo.buscanEmpleados.forEach {
            batch.set(db().collection("anuncios").document(), datosAnuncio(it.copy(creado = t++), "empleados"))
        }
        batch.commit()
            .addOnSuccessListener { ok() }
            .addOnFailureListener { error(it.message ?: "Error desconocido") }
    }

    // ---------- acceso del creador ----------

    fun hayUsuario(): Boolean = try {
        auth().currentUser != null
    } catch (e: Exception) {
        false
    }

    fun entrar(correo: String, clave: String, ok: () -> Unit, error: (String) -> Unit) {
        auth().signInWithEmailAndPassword(correo.trim(), clave)
            .addOnSuccessListener { ok() }
            .addOnFailureListener { error("Correo o contraseña incorrectos") }
    }

    fun salir() {
        try {
            auth().signOut()
        } catch (e: Exception) {
            // nada que cerrar
        }
    }
}
