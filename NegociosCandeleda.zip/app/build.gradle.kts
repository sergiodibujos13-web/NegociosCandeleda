plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

// En GitHub el google-services.json se sube a la raíz del repositorio; aquí se copia a app/.
val gsRaiz = rootProject.file("google-services.json")
val gsApp = file("google-services.json")
if (gsRaiz.exists() && !gsApp.exists()) gsRaiz.copyTo(gsApp)

android {
    namespace = "es.candeleda.negocios"
    compileSdk = 34

    defaultConfig {
        applicationId = "es.candeleda.negocios"
        minSdk = 26
        targetSdk = 34
        val ejecucion = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = ejecucion
        versionName = "1.$ejecucion"
    }

    // Firma fija: el workflow crea firma.jks en la raíz a partir del secreto DEBUG_KEYSTORE_BASE64.
    val firma = rootProject.file("firma.jks")
    if (firma.exists() && firma.length() > 0) {
        signingConfigs {
            create("fija") {
                storeFile = firma
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        debug {
            if (firma.exists() && firma.length() > 0) signingConfig = signingConfigs.getByName("fija")
        }
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}
