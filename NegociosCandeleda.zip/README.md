# Negocios Candeleda

App Android con el directorio de negocios del pueblo.

## Datos en la nube (Firebase)
Los negocios y anuncios de empleo se leen en vivo de Firebase (Firestore): lo que cambies lo ve
todo el mundo al momento, sin actualizar la app. Los archivos `negocios.json` y `empleo.json` de
`app/src/main/assets/` solo se usan como copia por si no hay conexión la primera vez, y para el
botón "Importar datos iniciales".

## Panel del creador
Mantén pulsado el logo de la pantalla de inicio. Entra con tu correo y contraseña de Firebase.
Desde el panel añades, editas y borras negocios y anuncios.

## Reglas de seguridad (Firestore > Reglas)
Todos pueden leer; solo tu correo puede escribir. Sustituye TU_CORREO.
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function esCreador() {
      return request.auth != null && request.auth.token.email == 'TU_CORREO';
    }
    match /negocios/{id} {
      allow read: if true;
      allow write: if esCreador();
    }
    match /anuncios/{id} {
      allow read: if true;
      allow write: if esCreador();
    }
  }
}
```

## google-services.json
Descárgalo de Firebase (app Android `es.candeleda.negocios`) y súbelo a la raíz del repositorio,
al lado del ZIP. Al compilar se copia solo a la carpeta app/.

## Cambiar las fotos
Están en `app/src/main/res/drawable-nodpi/`: `fondo.jpg` (fondo de la app),
`logo_banner.jpg` (cabecera con el texto) e `ic_launcher.png` (icono).
Mantén los mismos nombres.

## Compilar
Sube todo a un repositorio de GitHub (incluida la carpeta `.github`).
En la pestaña Actions se compila solo y el APK sale en "Artifacts".
