# Negocios Candeleda

App Android con el directorio de negocios del pueblo.

## Añadir o cambiar negocios
Edita `app/src/main/assets/negocios.json`. Cada negocio tiene:
nombre, categoria, descripcion, telefono, web, direccion, horario y carta.
- Si `telefono`, `web` o `direccion` van vacíos, ese botón no aparece.
- Horario: claves lun, mar, mie, jue, vie, sab, dom; cada día es una lista de tramos
  como "09:00-14:00". Lista vacía = cerrado. Horario `{}` = "no disponible".
- Las categorías salen solas de lo que escribas en `categoria`.

## Cambiar las fotos
Están en `app/src/main/res/drawable-nodpi/`: `fondo.jpg` (fondo de la app),
`logo_banner.jpg` (cabecera con el texto) e `ic_launcher.png` (icono).
Mantén los mismos nombres.

## Compilar
Sube todo a un repositorio de GitHub (incluida la carpeta `.github`).
En la pestaña Actions se compila solo y el APK sale en "Artifacts".
